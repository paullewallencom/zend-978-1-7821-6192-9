<?php
return array(
    'zend_server_gateway' => array(
        'configs' => array(
            __DIR__ . '/gateway.xml'
        )
    )        
);
